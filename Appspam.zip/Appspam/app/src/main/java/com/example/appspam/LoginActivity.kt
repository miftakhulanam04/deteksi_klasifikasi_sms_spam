package com.example.appspam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_klasifikasi.*
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnBackLoginListener()
        btnLoginListener()
    }
    private fun btnBackLoginListener(){
        back_1.setOnClickListener {
            startActivity(Intent(this, LoginRegisterActivity::class.java))
        }
    }
    private fun btnLoginListener(){
        btnL.setOnClickListener {
            startActivity(Intent(this, KlasifikasiActivity::class.java))
        }
    }
}